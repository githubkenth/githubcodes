module Practical {
}