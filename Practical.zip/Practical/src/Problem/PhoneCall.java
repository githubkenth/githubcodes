package Problem;

import java.util.*;

public class PhoneCall {

		  public static int getNumber(char uppercaseLetter) {
		   
		   char[] letter = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',};
		   
		   int[] value = {2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9, 9, 9, 9,};
		   
		   for(int i = 0; i < letter.length; i++){
		     if(uppercaseLetter == letter[i]){
		       return value [i];
		     }
		   }
		   return 0;
		  }
		  public static void main(String[] args){
		    Scanner input = new Scanner(System.in);
		    System.out.print("Enter the phone number: ");
		    
		    String getNumber = input.nextLine();
		    for(int i = 0; i < getNumber.length(); i++){ 
		    
		    char c = getNumber.toUpperCase().charAt(i);
		    int value = getNumber(c);
		    
		    if (value != 0) 
		    {
		      System.out.print(value);
		    }
		    else{
		      System.out.print(c);
		      }
		    }
		    input.close();
		  }
		}
