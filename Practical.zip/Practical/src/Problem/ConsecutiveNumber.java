package Problem;

import java.util.Scanner;

public class ConsecutiveNumber{

	public static void main(String[] args) 
			{
			    boolean con = false;
			    Scanner scan = new Scanner(System.in);
			    System.out.print("Enter Number: ");
			    String input = scan.nextLine();
			    String[] numbers = input.split(" ");
			    int occurs=0;
				for(int i = 0;i<numbers.length; i++)
				{
				    if(i<numbers.length-1)
			        {
			            if(!numbers[i].equals("0"))
			            {
		        	        if(numbers[i].equals(numbers[i+1]))
		        	        {
		        	            occurs++;
		        	        }
		        	        else
		        	        {
		        	            occurs=0;
		        	        }
		        	        
		        		        
		        		    if(occurs==2)
		        		    {
		        		        System.out.println("Consecutive value found for "+numbers[i]);
		        		        con=true;
		        		    }
			            }
			        }
				}
				if(con==false)
				{
				    System.out.println("Consecutive value not fount");
				}
			}
		}
