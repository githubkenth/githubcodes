package Problem;

import java.util.Scanner;

public class LetsMakeACall {

	
			public static void main(String[] args)
			{
			    Scanner scan = new Scanner(System.in);
			    System.out.print("Enter Number: ");
			    String input = scan.nextLine();
			    String[] numbers = input.split("");
				for(int i = 0;i<input.length(); i++)
				{
				    if(input.toUpperCase().charAt(i)>='A'&&input.toUpperCase().charAt(i)<='C')
				    {
				        System.out.print("2");
				    }
				    else if(input.toUpperCase().charAt(i)>='D'&&input.toUpperCase().charAt(i)<='F')
				    {
				        System.out.print("3");
				    }
				    else if(input.toUpperCase().charAt(i)>='G'&&input.toUpperCase().charAt(i)<='I')
				    {
				        System.out.print("4");
				    }
				    else if(input.toUpperCase().charAt(i)>='J'&&input.toUpperCase().charAt(i)<='L')
				    {
				        System.out.print("5");
				    }
				    else if(input.toUpperCase().charAt(i)>='M'&&input.toUpperCase().charAt(i)<='O')
				    {
				        System.out.print("6");
				    }
				    else if(input.toUpperCase().charAt(i)>='P'&&input.toUpperCase().charAt(i)<='S')
				    {
				        System.out.print("7");
				    }
				    else if(input.toUpperCase().charAt(i)>='T'&&input.toUpperCase().charAt(i)<='V')
				    {
				        System.out.print("8");
				    }
				    else if(input.toUpperCase().charAt(i)>='W'&&input.toUpperCase().charAt(i)<='Z')
				    {
				        System.out.print("9");
				    }
				    else
				    {
				        System.out.print(input.charAt(i));
				    }
				}
				
			}
		}
