package Problem;

import java.util.Scanner;

public class ParralellLines{

 public static void main(String[] args) {
				double x1,y1;
				double x2,y2;
				
				Scanner scan = new Scanner(System.in).useDelimiter("\\n");
				System.out.print("Enter inputs of first lines: ");
				String[]line1 = scan.next().trim().split(" ");
				double[]line1nums = new double[line1.length];
				
				for(int i=0;i<line1.length;i++){
					line1nums[i]=Integer.parseInt(line1[i]);
				}
				
				x1 = line1nums[0];
				y1 = line1nums[1];
				x2 = line1nums[2];
				y2 = line1nums[3];
				
				double slope1 = (y2-y1)/(x2-x1);
				
				double x3,y3;
				double x4,y4;
				
				System.out.print("Enter inputs of second lines: ");
				String[]line2 = scan.next().trim().split(" ");
				double[]line2nums = new double[line2.length];
				
				for(int i=0;i<line2.length;i++){
					line2nums[i]=Integer.parseInt(line2[i]);
				}
				
				x3 = line2nums[0];
				y3 = line2nums[1];
				x4 = line2nums[2];
				y4 = line2nums[3];
				
				double slope2 = (y4-y3)/(x4-x3);
				
				if(slope1!=slope2){
					if(x1==x2||x3==x4){
						System.out.println("Intersecting - one vertical");
					}else
					System.out.println("Intersecting");
				}
				
				
					if(slope1==slope2) {
						if(x1==x2&&x3==x4){
							System.out.println("Parallel - both vertical");
						}else
						System.out.println("Parallel");
					}

			}

		}
