package Problem;

import java.util.Arrays;
import java.util.Scanner;

public class SentenceMakerr {
			
		    public static void isPossible(String str1, String str2) {
		     
		       int arr[] = new int[256];
		 
		        Arrays.fill(arr, 0);
		        
		        int l1 = str1.length();
		        int l2 = str2.length();
		 
		        int i, j;
		 	        
		        boolean possible = true;
		 
		        for (i = 0; i < l1; i++) {
		          
		            arr[str1.charAt(i)] = 1;
		        }
		 
		        for (i = 0; i < l2; i++) {
		 
		            if (str2.charAt(i) != ' ') {
		 
		                if (arr[str2.charAt(i)] == 1)
		                    continue;
		 
		                else {
		                    possible = false;
		                    break;
		                }
		            }
		        }
		 
		        if (possible) {
		            System.out.println("possible");
		        } else {
		            System.out.println("not possible");
		        }
		    }
		 
		    public static void main(String args[])
		    {
		    	Scanner scan = new Scanner(System.in).useDelimiter("\\n");
		    	
		    	String str1;
		    	System.out.println("Enter the list of letters: ");
		    	str1 = scan.nextLine();

		    	String str2;
		    	System.out.println("Enter the sentence to be formed: ");
		    	str2 = scan.nextLine();

		        isPossible(str1, str2);
			    
			}
		}
