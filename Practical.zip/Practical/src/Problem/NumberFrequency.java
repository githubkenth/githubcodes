package Problem;

import java.util.Scanner;

public class NumberFrequency {

			public static void main(String[] args)
			{
			    int total = 0;
			    Scanner scan = new Scanner(System.in);
			    System.out.print("Enter Number: ");
			    String input = scan.nextLine();
			    
			    String[] numbers = input.split(" ");
			    String[] allnumbers = new String[numbers.length];
			    for(int i = 0;i<numbers.length; i++)
				{
				    boolean samenum=false;
				    String temp=numbers[i];
				    if(!temp.equals("0"))
				    {
		    		    for(int j = 0;j<total;j++)
		    		    {
		    		        if(temp.equals(allnumbers[j]))
		    		        {
		    		            samenum=true;
		    		        }
		    		        
		    		    }
		    		    if(samenum==false)
		    		    {
		    		        allnumbers[total]=numbers[i];
		    		        total++;
		    		    }
				    }
				}
				for(int i = 0;i<total; i++)
				{
				    int occurs=0;
				    for(int j = i;j<numbers.length;j++)
				    {
				        if(allnumbers[i].equals(numbers[j]))
				        {
				            occurs++;
				        }
				        
				    }
				    
				    if(occurs==1)
				    {
				        System.out.println(allnumbers[i]+" occurs: "+occurs+" time");
				    }
				    else
				    {
				        System.out.println(allnumbers[i]+" occurs: "+occurs+" times");
				    }
				}
			}
}
				
				
			
		
		

	


