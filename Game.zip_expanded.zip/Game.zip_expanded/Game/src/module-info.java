/**
 * 
 */
/**
 * @author Home
 *
 */
module Game {
	requires java.desktop;
}