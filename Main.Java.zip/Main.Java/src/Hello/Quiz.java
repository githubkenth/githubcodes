package Hello;

import java.util.Scanner;

public class Quiz {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in).useDelimiter("\\n");
		
		String[] studentList;
		String[] gradesByStudents;
		
		studentList = scan.nextLine().split(",");
		
		
		gradesByStudents = scan.nextLine().split(";");
		
		
		System.out.println("\nTotal Number of Students: " + studentList.length);
		System.out.println("===============================");
		for(int i=0; i<studentList.length; i++) {
			int sum = 0;
			int items = 0;
			System.out.print("Name: " + studentList[i].toUpperCase());
			String[] temp = gradesByStudents[i].split(" ");
			
			System.out.println("\nScores: " + gradesByStudents[i]);
			
			for (int j=0; j<temp.length; j++) {
				sum += Integer.parseInt(temp[j]);
				items++;
			}
			float ave = (sum / items);
			System.out.println("AVERAGE: " + ave);
			if (ave >=75) {
				System.out.println("STATUS: PASSED");
			}
			else {
				System.out.println("STATUS: FAILED");
			}
			System.out.println("===============================");
			System.out.println(" ");
		}
		}
}
