package Hello;

import java.util.Scanner;

public class SS {
      public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		String name, score;
		int Scores, numScores;
		float average = 0;
		
		System.out.println("NAMES: ");
		name = scan.next();
		System.out.println("SCORES: ");
		score = scan.next();
		
		String[] n = name.split(",");
		String[] s = score.split(";");
		
		System.out.println("Total students: " + n.length);
		
		for (String nn:n){
			System.out.println("Name: " + nn.toUpperCase());
			System.out.println("Scores: " + score);
			Scores = parseInt(s);
			numScores = s.length;
			average = Scores/ numScores;
			System.out.println("Average: "+ average);
			if (average >=75) {
				System.out.println("STATUS: PASSED");
			}else {
				System.out.println("STATUS: FAILED");
			}
			System.out.println(" ");
			
			
			
		}
		
		

	}

	private static int parseInt(String[] s) {
		// TODO Auto-generated method stub
		return 0;
	}

}
