package com.buksuIT.Practical;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Table {
	private static JTextField FirstName;
	private static JTextField LastName;
	private static JTextField PhoneNumber;
	
	public static void main(String[]args) {
		JTable table = new JTable();
		Object[] columns = {"First name", "Last name", "Phone number"};
		DefaultTableModel model = new DefaultTableModel();
		
		JFrame frame = new JFrame("Table");
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 20));
		frame.getContentPane().setBackground(Color.BLACK);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100,100,771,618);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);
		frame.setResizable(true);
		
		model.setColumnIdentifiers(columns);
		table.setModel(model);
		table.setBackground(Color.WHITE);
		table.setForeground(Color.BLACK);
		table.setSelectionBackground(Color.RED);
		table.setGridColor(Color.RED);
		table.setSelectionForeground(Color.WHITE);
		table.setFont(new Font("Tahoma", Font.PLAIN, 17));
		table.setRowHeight(30);
		table.setAutoCreateRowSorter(true);
		
		JScrollPane pane = new JScrollPane(table);
	    pane.setForeground(Color.RED);
	    pane.setBackground(Color.WHITE);
	    pane.setBounds(10,10,737,391);
	    frame.getContentPane().add(pane);
	    
	    FirstName = new JTextField();
	    FirstName.setFont(new Font("Tahoma", Font.PLAIN, 10));
	    FirstName.setBounds(272, 426, 141, 19);
	    frame.getContentPane().add(FirstName);
	    FirstName.setColumns(10);
	    
	    LastName = new JTextField();
	    LastName.setBounds(272, 468, 141, 19);
	    frame.getContentPane().add(LastName);
	    LastName.setColumns(10);
	    
	    PhoneNumber = new JTextField();
	    PhoneNumber.setBounds(272, 510, 141, 19);
	    frame.getContentPane().add(PhoneNumber);
	    PhoneNumber.setColumns(10);
	    
	    JLabel lblLastName = new JLabel("LastName");
	    lblLastName.setForeground(Color.WHITE);	    
	    lblLastName.setBounds(107, 468, 69, 19);
	    frame.getContentPane().add(lblLastName);
	    
	    JLabel lblFirstName = new JLabel("FirstName");
	    lblFirstName.setForeground(Color.WHITE);
	    lblFirstName.setBounds(107, 429, 83, 13);
	    frame.getContentPane().add(lblFirstName);
	    
	    JLabel lblPhoneNumber = new JLabel("PhoneNumber");
	    lblPhoneNumber.setForeground(Color.WHITE);
	    lblPhoneNumber.setBounds(107, 513, 83, 13);
	    frame.getContentPane().add(lblPhoneNumber);
	    
	    Object[]row = new Object[4];
	    
	    JButton btnNewButton = new JButton("Add");
	    btnNewButton.setBounds(540, 425, 85, 21);
	    frame.getContentPane().add(btnNewButton);
	    btnNewButton.addActionListener(new ActionListener(){

			@Override 
			public void actionPerformed(ActionEvent args0) {
				row[0] = FirstName.getText();
				row[1] = LastName.getText();
				row[2] = PhoneNumber.getText();
				
				model.addRow(row);
			}
	    });
	    JButton btnNewButton_1 = new JButton("Delete");	    
	    btnNewButton_1.setBounds(540, 467, 85, 21);
	    frame.getContentPane().add(btnNewButton_1);
	    btnNewButton_1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent args0) {
				// TODO Auto-generated method stub
				
			}
	    });
	    	
	     				
		frame.setVisible(true);
		
	}
}
