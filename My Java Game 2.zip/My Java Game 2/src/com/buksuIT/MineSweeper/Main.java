package com.buksuIT.MineSweeper;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Main implements ActionListener{
	
	JFrame frame;
	JLabel label;
	JButton playButton, helpButton, quit;

	
	Main(){
		
		
		frame= new JFrame("Minesweeper");
		frame.setLocationRelativeTo(null);
	    frame.getContentPane().setBackground(Color.BLACK);
		frame.setMinimumSize(new Dimension(500, 500));
		frame.setLayout(null);
		
		label = new JLabel("Minesweeper");
		label.setForeground(Color.white);
		label.setFont(new Font("Serif",Font.BOLD,50));
		label.setBounds(100, 100 , 300, 70);
		
		playButton = new JButton("Play");
		playButton.setBounds(200, 200 , 100, 30);
		playButton.setFocusable(false);
		playButton.addActionListener(this);
		playButton.setBackground(Color.BLACK);
		playButton.setForeground(Color.WHITE);
		
		helpButton = new JButton("Help");
		helpButton.setBounds(200, 250 , 100, 30);
		helpButton.setFocusable(false);
		helpButton.addActionListener(this);
		helpButton.setBackground(Color.BLACK);
		helpButton.setForeground(Color.WHITE);
		
		quit = new JButton("Quit");
		quit.setBounds(200, 300 , 100, 30);
		quit.setFocusable(false);
		quit.addActionListener(this);
		quit.setBackground(Color.BLACK);
		quit.setForeground(Color.WHITE);
		
		frame.add(quit);
		frame.add(helpButton);
		frame.add(playButton);
		frame.add(label);
		frame.setVisible(true);
	}
	

	public static void main (String[] args ){

		
		 //X-cordinate==number of colums==width of the mine fields
		 //Y-cordinate==number of rows == height of the mine fields
		//To run the game
		new Main();
		

}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()== playButton) {
			MineSweeper Game = new MineSweeper();
			
			JLabel gameLabel = new JLabel();
			playButton.setVisible(false);
			helpButton.setVisible(false);
			quit.setVisible(false);
			frame.add(gameLabel);
			frame.setVisible(false);
		}
		if(e.getSource()==helpButton) {
			JOptionPane.showMessageDialog(null, "\"Minesweeper rules are very simple:\r\n"
					+ "						- The board is divided into cells, with mines randomly distributed. \"\r\n"
					+ "						- To win, you need to open all the cells. \\r\\n\"\r\n"
					+ "						- The number on a cell shows the number of mines adjacent to it.\r\n"
					+ "						- Using this information, you can determine cells that are safe, and cells that contain mines\r\n"
					+ "						- Cells suspected of being mines can be marked with a flag using the right mouse button.\r\n"
					+ "				\"How To Play\" \nRight Click = Flag/Unflag\nLeft Click = Reveal Cells");
		}
		if(e.getSource()==quit) {
			frame.dispose();
		}
	}
}
