package com.buksu.student.list;

import java.util.Scanner;

public class MainMenu {
	Scanner scan = new Scanner(System.in);
	SubjectController subcon;
	StudentController studcon;
	GradesController gradescon;
	StudentMenu studentMenu;
	SubjectMenu subjectMenu;
	GradesMenu gradesMenu;
	
	public MainMenu(SubjectController subcon, StudentController studcon,GradesController gradescon) {
		this.subcon = subcon;
		this.studcon = studcon;
		this.gradescon = gradescon;
		this.subjectMenu = new SubjectMenu(this,subcon);
		this.studentMenu = new StudentMenu(this,studcon);
		this.gradesMenu = new GradesMenu(this,subcon,studcon,gradescon);
	}

	public void showMenu()
	{
		System.out.println("---------------------------------MAIN MENU----------------------------------");
		System.out.println("1.Student Menu");
		System.out.println("2.Subject Menu");
		System.out.println("3.Grades Menu");
		System.out.println("4.Exit");
		System.out.println("---------------------------------MAIN MENU----------------------------------");
		System.out.print(" Please Select: ");
		
		String input = scan.nextLine();
		switch(input)
		{
			case "1": 
				studentMenu.showMenu();
				break;
			case "2": 
				subjectMenu.showMenu();
				break;
			case "3": 
				gradesMenu.showMenu();
				break;
			case "4": 
				System.out.println("program terminate!");
				break;
		   default: 
				System.out.println("\nInvalid Input!");
				showMenu();
				break;
		}
	}

}
