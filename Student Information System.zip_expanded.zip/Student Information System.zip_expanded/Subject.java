package com.buksu.student.list;

import java.util.LinkedList;

public class Subject {
	String id,name;
	LinkedList<Grades> gradesList;
	
	public Subject(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public LinkedList<Grades> getGradesList(){
		return gradesList;
	}

	public void setGradesList(LinkedList<Grades> gradesList) {
		this.gradesList = gradesList;
	}

	public String getStudentGrades(String id){
		String s=" ";
		for(Grades g: gradesList)
		{
			if(g.getId().trim().equalsIgnoreCase(id))
			{
				s=g.getGrade();
			}
		}
		 return s;
	 }
	
}