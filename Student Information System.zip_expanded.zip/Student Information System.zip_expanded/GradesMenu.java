package com.buksu.student.list;


	import java.util.Scanner;

	public class GradesMenu {
		Scanner scan = new Scanner(System.in).useDelimiter("\n");
		MainMenu mainMenu;
		StudentController studcon;
		GradesController gradescon;
		
		
		public GradesMenu(MainMenu mainMenu, SubjectController subcon, StudentController studcon,GradesController gradescon) {
			this.mainMenu=mainMenu;
			this.studcon=studcon;
			this.gradescon=gradescon;
		}
		public void showMenu()
		{
			System.out.println("-----------------------------------GRADES MENU---------------------------------------");
			System.out.println("Give Student Grades     -->  give,Student Id,Subject code,Grade        (Ex: give,1001,T232,1.5)");
			System.out.println("Update Student Grades   -->  update,Student Id,Subject code,Grade      (Ex: update,1001,T232,1)");
			System.out.println("EXIT                        (Go to Main Menu)");
			System.out.println("-----------------------------------GRADES MENU---------------------------------------");
			System.out.print("Please Input Command: ");
			
			String input = scan.nextLine();
			String[] inputarr = input.split(",");

			switch(inputarr[0].toLowerCase().trim())
			{
				case "give":
					studcon.giveStudentGrades(inputarr[1], inputarr[2], inputarr[3]);
					showMenu();
					break;
				case "update": 
					studcon.updateGrade(inputarr[1], inputarr[2], inputarr[3]);
					showMenu();
					break;
				case "exit":
					mainMenu.showMenu();
					break;
					default:
						System.out.println("Invalid Input!");
						showMenu();
						break;
			}
		}
	}
