package com.buksu.student.list;

import java.util.LinkedList;

public class SubjectController  implements SubjectMethods{
	LinkedList<Subject> subjectList = new LinkedList<Subject> ();
	
	@Override
	public Subject add(Subject s) {
		Subject temp = getSubject(s.getId());
		if (temp != null) {
			System.out.println("\nFailed adding Subject! Subject already exist.");
		
		} else {
			subjectList.add(s);
		}
		return s;
	}

	@Override
	public Subject update(Subject s) {
		for (Subject temp : subjectList) {
			if (temp.getId().trim().equalsIgnoreCase(s.getId())) {
				int index = subjectList.indexOf(temp);
				System.out.println(index);
				subjectList.set(index, s);
				break;
			}
		}
		return null;
	}

	@Override
	public Subject delete(Subject s) {
		subjectList.remove(s);
		return s;
	}

	@Override
	public Subject getSubject(String id) {
		Subject s = null;
		for (Subject temp : subjectList) {
			if (temp.getId().trim().equalsIgnoreCase(id)) {
				s = temp;
				break;
			}
		}
		return s;
	}

	@Override
	public void getAllSubject() {
		System.out.println("\n\nSubject List: ");
		System.out.println("Subject Code\t\t\t\t\t\tSubject Description");
		System.out.println("------------------------------------------------------------------------------");
		for (Subject s : subjectList) {
			System.out.printf("%s\t\t\t\t\t\t\t\t%s\n", s.getId(), s.getName());
		}
		
	}
	@Override
	public void showSubject(Subject s) {
		if (s != null) {
			System.out.println("\n\nSubject Information: ");
			System.out.println("Subject\t\t\t\t\t\t\tDescription");
			System.out.println("------------------------------------------------------------------------------");
			System.out.printf("%s\t\t\t\t\t\t\t%s\n", s.getId(), s.getName());
		}
		
	}
	public void isExist(Subject s) {
		if (s == null) {
			System.out.println("\nSubject Code not found!");
		}
	}

	

}