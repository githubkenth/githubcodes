package com.buksu.student.list;

public class Main {
	public static void main(String[]args)
	{
		SubjectController subcon = new SubjectController();
		StudentController studcon = new StudentController(subcon);
		GradesController gradecon = new GradesController(studcon);
		
		MainMenu mainMenu = new MainMenu(subcon,studcon,gradecon);
		
		mainMenu.showMenu();
	}

}