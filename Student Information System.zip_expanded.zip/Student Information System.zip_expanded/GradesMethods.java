package com.buksu.student.list;

public interface GradesMethods {
	public Grades addGrades(Grades g);
	public Grades updateGrades(Grades g);
}
