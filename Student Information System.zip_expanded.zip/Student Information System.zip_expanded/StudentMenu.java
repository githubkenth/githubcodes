package com.buksu.student.list;

import java.util.Scanner;

public class StudentMenu {
	Scanner scan = new Scanner(System.in).useDelimiter("\n");
	MainMenu mainMenu;
	StudentController sc;
	
	
	public StudentMenu(MainMenu mainMenu,  StudentController studcon) {
		this.mainMenu = mainMenu;
		this.sc = studcon;
	}
	public void showMenu()
	{
		System.out.println("-----------------------------------STUDENT MENU---------------------------------------");
		System.out.println("Add Student      --> add,Id,Name,Address,Age          (Ex: add,1001,Devon,Goldstar,21)");
		System.out.println("Update Student   -->  update,Id,Name,Address,Age      (Ex: update,1001,Devon Sadaya,Goldstar,21)");
		System.out.println("Delete Student   -->  delete,Id                       (Ex: delete,1001)");
		System.out.println("Search Student   -->  search,Id                       (Ex: search,1001)");
		System.out.println("Get all Student  -->  all                             (Ex: all)");
		System.out.println("Enroll Student   --> enroll,Id,Subject Code,          (Ex: enroll,1001,T232)");
		System.out.println("EXIT(go to Main Menu)                                 (Ex: exit)");
		System.out.println("-----------------------------------STUDENT MENU---------------------------------------");
		System.out.print("Please Input Command: ");
		
		String input = scan.nextLine();
		String[] inputarr = input.split(",");
		
		Student s;
		switch(inputarr[0].toLowerCase().trim())
		{
			case "add":
				s = new Student(inputarr[1],inputarr[2],inputarr[3],Integer.parseInt(inputarr[4]));
				sc.add(s);
				sc.getAllStudent();
				showMenu();
				break;
			case "update": 
				s = new Student(inputarr[1],inputarr[2],inputarr[3],Integer.parseInt(inputarr[4]));
				sc.updateStudent(s);
				sc.getAllStudent();
				showMenu();
				break;
			case "delete": 
				sc.delete(inputarr[1]);
				sc.getAllStudent();
				showMenu();
				break;
			case "search":
				s = sc.getStudent(inputarr[1]);
				sc.showStudent(s);
				showMenu();
				break;
			case "all":
				sc.getAllStudent();
				showMenu();
				break;
			case "enroll":
				sc.enroll(inputarr[1], inputarr[2]);
				showMenu();
				break;
			case "exit":
					mainMenu.showMenu();
				break;
			default:
				System.out.println("\nInvalid COMMAND!!");
				showMenu();
				break;

		}
	}
}

