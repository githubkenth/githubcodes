package com.buksu.student.list;

import java.util.Scanner;

public class SubjectMenu {
	Scanner scan = new Scanner(System.in).useDelimiter("\n");
	MainMenu mainMenu;
	SubjectController sc;
	
	public SubjectMenu(MainMenu mainMenu, SubjectController subcon) {
		this.mainMenu=mainMenu;
		this.sc = subcon;
	}
	public void showMenu()
	{
		System.out.println("-----------------------------------SUBJECT MENU---------------------------------------");
		System.out.println("Add Subject       -->  add,code,description         (Ex: add,T232,OOP)");
		System.out.println("Update Subject    -->  update,code,description      (Ex: update,T232,OOP)");
		System.out.println("Delete Subject    -->  delete,code                  (Ex: delete,T232)");
		System.out.println("Search Subject    -->  search,code                  (Ex: search,T232)");
		System.out.println("Get all Subject   -->  all                          (Ex: all)");
		System.out.println("EXIT(go to Main Menu)                               (Ex: exit)");
		System.out.println("-----------------------------------SUBJECT MENU---------------------------------------");
		System.out.print("Please Input Command: ");
		
		String input = scan.nextLine();
		String[] inputarr = input.split(",");
		Subject s;
		switch(inputarr[0].toLowerCase().trim())
		{
			case "add":
				s = new Subject(inputarr[1],inputarr[2]);
				sc.add(s);
				sc.getAllSubject();
				showMenu();
				break;
			case "update": 
				s = new Subject(inputarr[1],inputarr[2]);
				sc.update(s);
				sc.getAllSubject();
				showMenu();
				break;
			case "delete": 
				s = sc.getSubject(inputarr[1]);
				sc.isExist(s);
				sc.delete(s);
				sc.getAllSubject();
				showMenu();
				break;
			case "search":
				if(inputarr.length==2) {
					s = sc.getSubject(inputarr[1]);
					sc.showSubject(s);
				}
				showMenu();
				break;
			case "all":
				sc.getAllSubject();
				showMenu();
				break;
			case "exit":
				mainMenu.showMenu();
				break;
			default:
				System.out.println("\nInvalid Input!");
				showMenu();
				break;
		}
	}

}