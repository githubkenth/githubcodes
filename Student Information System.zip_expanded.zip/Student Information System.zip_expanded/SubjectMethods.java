package com.buksu.student.list;

public interface SubjectMethods {
	public Subject add(Subject s);
	public Subject update(Subject s);
	public Subject delete(Subject s);
	public Subject getSubject(String id);
	public void getAllSubject();
	public void showSubject(Subject s);
}