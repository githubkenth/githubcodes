package com.buksu.student.list;

import java.util.LinkedList;

public class Grades {
	String id,code;
	String grade;
	LinkedList<Student> studentList;
	LinkedList<Subject> subjectList ;
	
	public LinkedList<Subject> getSubjectList() {
		return subjectList;
	}
	public void setSubjectList(LinkedList<Subject> subjectList) {
		this.subjectList = subjectList;
	}
	
	public Grades(String id, String code, String grade) {
		this.id = id;
		this.code = code;
		this.grade = grade;
	}
	public Grades(String grade) {
		
		this.grade = grade;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public LinkedList<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(LinkedList<Student> studentList) {
		this.studentList = studentList;
	}
	
	
}