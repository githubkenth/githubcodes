package com.buksuIT.SIS;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class MyFrame {
	JFrame mainFrame;
	JTabbedPane tabbedpane;
	JPanel studentpanel;
	JPanel studentoptionpanel;
	JPanel studentcontentpanel;
	JButton addStudent;
	JScrollPane scrollpane;
	JTable TableforStudent;
	DefaultTableModel model;
	Object[] column = {"STUDENT ID", "NAME", "ADDRESS", "AGE"};
	Object[] rows = new Object[4];
	
	MyFrame() {
		mainFrame = new JFrame("Student Information System");
		mainFrame.setMinimumSize(new Dimension(900,600));
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setLocationRelativeTo(null);
		
		
		tabbedpane = new JTabbedPane();
		mainFrame.add(tabbedpane);
		
		studentpanel = new JPanel();
		studentpanel.setBackground(Color.red);
		studentpanel.setSize(tabbedpane.getWidth(), tabbedpane.getHeight());
		studentpanel.setLayout(new BorderLayout());
		tabbedpane.addTab("Student", studentpanel);
		tabbedpane.addTab("Subject", null);
		
		studentoptionpanel = new JPanel();
		studentoptionpanel.setBackground(Color.blue);
		studentoptionpanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		studentoptionpanel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		studentpanel.add(studentoptionpanel, BorderLayout.NORTH);
		
		studentcontentpanel = new JPanel();
		studentcontentpanel.setLayout(new BorderLayout());
		studentcontentpanel.setBackground(Color.cyan);
		studentpanel.add(studentcontentpanel, BorderLayout.CENTER);
		
		addStudent = new JButton("Add Student");
		studentoptionpanel.add(addStudent);
		addStudent.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				JFrame newtab = new JFrame("Add Student");

				
				newtab.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				newtab.setSize(650, 200);
				newtab.setLayout(null);
				newtab.setLocationRelativeTo(mainFrame);
				
				JPanel panel = new JPanel();
				panel.setBounds(0, 0, 650, 125);
				panel.setLayout(null);
				
				JTextField	id = new JTextField();
				id.setBounds(50, 25, 90, 20);
				panel.add(id);
				
				JLabel	idlbl = new JLabel("ID:");
				idlbl.setBounds(30, 20, 35, 35);
				panel.add(idlbl);
				
				JTextField	 name = new JTextField();
				name.setBounds(230, 25, 85, 20);
				panel.add(name);
				
				JLabel	namelbl = new JLabel("NAME:");
				namelbl.setBounds(185, 10, 40, 50);
				panel.add(namelbl);
				
				JTextField	address = new JTextField();
				address.setBounds(410, 25, 85,20 );
				panel.add(address);
				
				JLabel		addresslbl = new JLabel("ADDRESS:");
				addresslbl.setBounds(340, 10, 75, 50);
				panel.add(addresslbl);
				
				JTextField	age = new JTextField();
				age.setBounds(560, 25, 40, 20);
				panel.add(age);
				
				JLabel		agelbl = new JLabel("AGE:");
				agelbl.setBounds(520, 10, 75, 50);
				panel.add(agelbl);

				JButton add = new JButton("Save");
				add.setBounds(240, 90, 120, 40);
				add.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						
//						mainframe mainFrame = mainframe();
						if (id.getText().equals("") || name.getText().equals("") || address.getText().equals("") || age.getText().equals("")) {
							JOptionPane.showMessageDialog(null, "Please fill all Components");
						}
						else {
							rows[0] = id.getText();
							rows[1] = name.getText();
							rows[2] = address.getText();
							rows[3] = age.getText();
							//mFrame.model.setColumnIdentifiers(mFrame.column);
							model.addRow(rows);
							
					
							
							
							id.setText("");
							name.setText("");
							address.setText("");
							age.setText("");
						}
					}
					
				});
					panel.add(add);
				
				
				newtab.add(panel);
				newtab.setVisible(true);
			}
		});
		
		
		scrollpane = new JScrollPane();
		studentcontentpanel.add(scrollpane, BorderLayout.CENTER);
		
		TableforStudent = new JTable();
		
		model = new DefaultTableModel();
		model.setColumnIdentifiers(column);
		TableforStudent.setModel(model);
		scrollpane.setViewportView(TableforStudent);
		
		
		
		
		
		mainFrame.setVisible(true);
	}
	
}