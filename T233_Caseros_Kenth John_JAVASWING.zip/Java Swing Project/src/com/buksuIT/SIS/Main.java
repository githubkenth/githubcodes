package com.buksuIT.SIS;

public class Main {

	
	//Kenth John B. Caseros
	//Object Oriented Programming
	//T233
	//Assignment
	public static void main(String[] args) {
		
		new MyFrame();

	}

}