package com.buksuIT.GUI;

import javax.swing.*;


import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;


public class Main extends JFrame{
	private static JTextField textField;
	private static JTextField textField_1;
	private static JTextField textField_2;
	
	
public static void main(String[]args) {	

	Main frame = new Main();
	frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 20));
	frame.getContentPane().setBackground(Color.WHITE);
	frame.getContentPane().setForeground(Color.WHITE);
	frame.setBounds(100,100,771,618);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.getContentPane().setLayout(null);
}	
	public Main{
	
	JPanel panel = new JPanel();
	
	 ListenForButton listenForButton = new ListenForButton();

   
	panel.add(textField);
     panel.add(textField_1);

     /*
      * Adds elements to panel
      */

     getContentPane().add(panel);
	
	textField = new JTextField();
	textField.setBounds(71, 21, 180, 19);
	frame.getContentPane().add(textField);
	textField.setColumns(10);
	
	textField_1 = new JTextField();
	textField_1.setBounds(289, 21, 180, 19);
	frame.getContentPane().add(textField_1);
	textField_1.setColumns(10);
	
	textField_2 = new JTextField();
	textField_2.setBounds(503, 21, 180, 19);
	frame.getContentPane().add(textField_2);
	textField_2.setColumns(10);
	panel.add(textField_2);
	
	JButton btnNewButton = new JButton("+");
	btnNewButton.setBounds(615, 60, 68, 47);
	frame.getContentPane().add(btnNewButton);
	
	JButton btnNewButton_1 = new JButton("-");
	btnNewButton_1.setBounds(615, 121, 68, 47);
	frame.getContentPane().add(btnNewButton_1);
	
	JButton btnNewButton_1_1 = new JButton("*");
	btnNewButton_1_1.setBounds(615, 178, 68, 47);
	frame.getContentPane().add(btnNewButton_1_1);
	
	JButton btnNewButton_1_2 = new JButton("/");
	btnNewButton_1_2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		}
	});
	btnNewButton_1_2.setBounds(615, 235, 68, 47);
	frame.getContentPane().add(btnNewButton_1_2);
	frame.setLocationRelativeTo(null);
	frame.setResizable(true);
	frame.setVisible(true);
	}
	}
	 private static Container getContentPane() {
		// TODO Auto-generated method stub
		return null;
	}
	private class ListenForButton implements ActionListener {


	        @Override
	        public void actionPerformed(ActionEvent e) {
	            
	            double number1 = 0;
	            double number2 = 0;
	            
	            

	            try {
	                number1 = Double.parseDouble(textField1.getText());
	                number2 = Double.parseDouble(textField2.getText());
	            } catch (Exception error) {
	                error.printStackTrace();
	                System.out.println("Something went wrong.");
	                textField3.setText("Error");
	                boolean b3 = Pattern.matches("^(?!.*\\.\\.)[a-zA-Z0-9_.]+$", (CharSequence) e.getSource());
	            }
	            
	            
	            
	            if (e.getSource() == button1) {
	                textField3.setText(number1 + number2 + "");
	            } else if (e.getSource() == button2) {
	                textField3.setText(number1 - number2 + "");
	            } else if (e.getSource() == button3) {
	                textField3.setText(number1 * number2 + "");
	            } else if (e.getSource() == button4) {
	                textField3.setText(number1 / number2 + "");
	            } 
	             
	           }
	
	
	}
}

