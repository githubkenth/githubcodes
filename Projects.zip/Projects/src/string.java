
public class string {

	public static void main(String[] args) {

		String name = "Kenth John B. Caseros is %d years old";
		
		System.out.println(name.length());
		System.out.println(name.toUpperCase());
		System.out.println(name.toLowerCase());
	
		int age =  20;
	System.out.printf(name, age);	
	}
	
	

}
