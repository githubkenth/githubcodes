
public class ifelse {

	public static void main(String[] args) {
	int time = 10;
	if (time < 10) {
		  System.out.println("Good morning.");
		} else if (time < 20) {
		  System.out.println("Good day.");
		} else {
		  System.out.println("Good evening.");
		}
	}
}
