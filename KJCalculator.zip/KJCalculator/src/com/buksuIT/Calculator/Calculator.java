package com.buksuIT.Calculator;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
public class Calculator extends JFrame implements ActionListener
{    
   JButton b10,b11,b12,b13,b14,b15; 
   JButton b[]=new JButton[10];
    int i,r,n1,n2;
    JTextField res;
    char op; 
   public Calculator()
  {
     super("Calulator");
      setLayout(new BorderLayout());
      JPanel p=new JPanel();
      p.setLayout(new GridLayout(4,4));
      for(int i=0;i<=9;i++)
      {
        b[i]=new JButton(i+"");
        p.add(b[i]);
        b[i].addActionListener(this);
        b[i].setBackground(Color.BLACK); 
        b[i].setForeground(Color.WHITE);
        b[i].setFont(new Font("", Font.BOLD,20));
      }
      b10=new JButton("+");
      p.add(b10);
      b10.addActionListener(this);
      b10.setBackground(Color.BLACK);
      b10.setForeground(Color.WHITE);
      b10.setFont(new Font("", Font.BOLD,20));


      b11=new JButton("-");
      p.add(b11);
      b11.addActionListener(this);
      b11.addActionListener(this);
      b11.setBackground(Color.BLACK);
      b11.setForeground(Color.WHITE);
      b11.setFont(new Font("", Font.BOLD,20));

      b12=new JButton("*");
      p.add(b12);
      b12.addActionListener(this);
      b12.setBackground(Color.BLACK);
      b12.setForeground(Color.WHITE);
      b12.setFont(new Font("", Font.BOLD,20));

      b13=new JButton("/");
      p.add(b13);
      b13.addActionListener(this);
      b13.setBackground(Color.BLACK);
      b13.setForeground(Color.WHITE);
      b13.setFont(new Font("", Font.BOLD,20));
 
      b14=new JButton("=");
      p.add(b14);
      b14.addActionListener(this);
      b14.setBackground(Color.BLACK);
      b14.setForeground(Color.WHITE);
      b14.setFont(new Font("", Font.BOLD,20));

      b15=new JButton("C");
      p.add(b15);
      b15.addActionListener(this);
      b15.setBackground(Color.BLACK);
      b15.setForeground(Color.WHITE);
      b15.setFont(new Font("", Font.BOLD,20));

      res=new JTextField(10);
      res.setBackground(Color.BLACK);
      res.setForeground(Color.ORANGE);
      res.setFont(new Font("", Font.BOLD,30));
      add(p,BorderLayout.CENTER);
      add(res,BorderLayout.NORTH);
      setVisible(true);
      setSize(300,350);
      
     }
public void actionPerformed(ActionEvent ae)
{
  JButton pb=(JButton)ae.getSource();
	if(pb==b15)
	{
	 r=n1=n2=0;
	 res.setText("");
	}
	else
		if(pb==b14)
		{
 		 n2=Integer.parseInt(res.getText());
  		 eval();
  		 res.setText(""+r);
		}

		else
		{
 		  boolean opf=false;
 		  if(pb==b10)
			{ op='+';
			  opf=true;
			}
 		  if(pb==b11)
			{ op='-';opf=true;}
		  if(pb==b12)
			{ op='*';opf=true;}
		  if(pb==b13)
			{ op='/';opf=true;}
	
		  if(opf==false)
		  {
  		   for(i=0;i<10;i++)
		   {
		  	if(pb==b[i])
     		  	{
           	   	String t=res.getText();
           		t+=i;
            		res.setText(t);
		  	}
		   }
		  }
		  else
		  {
    			n1=Integer.parseInt(res.getText());
     			res.setText("");
		  }
		}
}
int eval()
{
	switch(op)
	{
 	case '+':   r=n1+n2;  break;
 	case '-':    r=n1-n2;   break;
 	case '*':    r=n1*n2; break;
 	case '/':    r=n1/n2; break;
 
	}
	return 0;
}

  public static void main(String arg[])
  {
      new Calculator();
   }
}