package com.buksuIT.Calculator;

public class Main{
	//The constructor is called and all the operations are executed.
		public static void main(String arg[])
		  {
		      new Calculator();
		   }
		}