package com.buksuIT.AssiCalcu;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

public class Main extends JFrame {

    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    
    /*
	 * Creates a textfield
	 */
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;


    public static void main(String[] args) {
    	
    	/*
		 * Creates a frame
		 */
        Main frame = new Main();

        frame.setTitle("Calculator");
        frame.setSize(650, 500);      
        frame.setResizable(false);  
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public Main() {
        JPanel panel1 = new JPanel();
        
        /*
         * Creates operator buttons
         */
        
        textField1 = new JTextField(20);
        textField1.setBackground(Color.BLACK);
        textField1.setForeground(Color.WHITE);
        textField1.setFont(new Font("", Font.BOLD,10));
        
        textField2 = new JTextField(20);
        textField2.setBackground(Color.BLACK);
        textField2.setForeground(Color.WHITE);
        textField2.setFont(new Font("", Font.BOLD,10));

        /*
         * Sets textField3 to not editable
         */

        ListenForButton listenForButton = new ListenForButton();

        panel1.add(textField1);
        panel1.add(textField2);

        /*
         * Adds elements to panel
         */

        getContentPane().add(panel1);
        
        textField3 = new JTextField(20);
        textField3.setBackground(Color.BLACK);
        textField3.setForeground(Color.WHITE);
        textField3.setFont(new Font("", Font.BOLD,10));
        textField3.setEditable(false);
        panel1.add(textField3);
        
        button2 = new JButton("-");
        button2.setBackground(Color.BLACK);
        button2.setForeground(Color.WHITE);
        button2.setFont(new Font("", Font.BOLD,20));
        button2.addActionListener(listenForButton);
        panel1.add(button2);
        
         button3 = new JButton("*");
         button3.setBackground(Color.BLACK);
         button3.setForeground(Color.WHITE);
         button3.setFont(new Font("", Font.BOLD,20));
         button3.addActionListener(listenForButton);
         button1 = new JButton("+");
         button1.setBackground(Color.BLACK);
         button1.setForeground(Color.WHITE);
         button1.setFont(new Font("", Font.BOLD,20));
         button1.addActionListener(listenForButton);
         panel1.add(button1);
         panel1.add(button3);
         
         button4 = new JButton("/");
         button4.setVerticalAlignment(SwingConstants.BOTTOM);
         button4.setBackground(Color.BLACK);
         button4.setForeground(Color.WHITE);
         button4.setFont(new Font("", Font.BOLD,20));
         button4.addActionListener(listenForButton);
         panel1.add(button4);
    }

    private class ListenForButton implements ActionListener {


        @Override
        public void actionPerformed(ActionEvent e) {
            
            double number1 = 0;
            double number2 = 0;
            
            

            try {
                number1 = Double.parseDouble(textField1.getText());
                number2 = Double.parseDouble(textField2.getText());
            } catch (Exception error) {
                error.printStackTrace();
                System.out.println("Something went wrong.");
                textField3.setText("Error");
                boolean b3 = Pattern.matches("^(?!.*\\.\\.)[a-zA-Z0-9_.]+$", (CharSequence) e.getSource());
            }
            
            
            
            if (e.getSource() == button1) {
                textField3.setText(number1 + number2 + "");
            } else if (e.getSource() == button2) {
                textField3.setText(number1 - number2 + "");
            } else if (e.getSource() == button3) {
                textField3.setText(number1 * number2 + "");
            } else if (e.getSource() == button4) {
                textField3.setText(number1 / number2 + "");
            } 
             
           }
    }
}