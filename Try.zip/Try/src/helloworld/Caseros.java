package helloworld;

import java.util.ArrayList;
import java.util.Scanner;

public class Caseros {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in).useDelimiter("//n");
		Scanner lol = new Scanner(System.in);
		ArrayList<String> arrString = new ArrayList<>();
		ArrayList<String> months = new ArrayList<>();
		
		System.out.println("Enter seven days of the week");
		
		String[] arr = scan.nextLine().split(" ");
		for(String z:arr) {
			arrString.add(z);
		}
		System.out.println(arrString);
		System.out.println("Enter 5 Months:");
		String[] month = scan.nextLine().split(" ");
		for(String y:month) {
			months.add(y);
		}
		System.out.println(months);
		
		System.out.println("Remove 3 Days: ");
		for (int i=0; i<3; i++) {
			String[] remove = scan.nextLine().split(" ");
			for(String k:remove) {
				arrString.remove(k);
			}
		}
		System.out.println(arrString);
		
		
		for (int i=0; i<3; i++) {
			System.out.print("Input Months to Modify: ");
			int mod = lol.nextInt();
			
			System.out.print("Modify 4 Months: ");
			String modify = scan.nextLine();
			
			
				months.set( mod, modify);
			
			
		}
		System.out.println(months);
	}

}