package com.buksuIT.SIS;

import java.util.Scanner;

public class SubjectMenu {
	Scanner scan = new Scanner(System.in).useDelimiter("\\n");
	MainMenu mainMenu;
	SubjectController sc;
	
	public SubjectMenu(MainMenu mainMenu, SubjectController subcon) {
		this.mainMenu=mainMenu;
		this.sc = subcon;
	}
	//Display the Subject menu and the examples that needs to follow. 
	public void showMenu()
	{
		System.out.println("\n============================================SUBJECT MENU============================================");
		System.out.println("Add Subject           -->  add,code,description         (Ex: add,T232,OOP)");
		System.out.println("Update Subject        -->  update,code,description      (Ex: update,T232,Object Oriented Programming)");
		System.out.println("Delete Subject        -->  delete,code                  (Ex: delete,T232)");
		System.out.println("Search Subject        -->  search,code                  (Ex: search,T232)");
		System.out.println("Display all Subject   -->  display                      (Ex: display)");
		System.out.println("EXIT                  (Go to Main Menu)                 (Ex: exit)");
		System.out.println("============================================SUBJECT MENU============================================");
		System.out.print("Please Input Command: ");
		
		String input = scan.nextLine();
	//Splitting the input in the String using comma
		String[] inputarr = input.split(",");
		Subject s;
	//Expression of switch case.
		switch(inputarr[0].toLowerCase().trim())
		{
	//The values and the commands that needs to follow to add, update, delete, search, display, exit(go back to main menu),
	//and the default if the command is not followed. 
			case "add":
				s = new Subject(inputarr[1],inputarr[2]);
				sc.add(s);
				sc.displayAllSubject();
				showMenu();
				break;
			case "update": 
				s = new Subject(inputarr[1],inputarr[2]);
				sc.update(s);
				sc.displayAllSubject();
				showMenu();
				break;
			case "delete": 
				s = sc.getSubject(inputarr[1]);
				sc.isExist(s);
				sc.delete(s);
				sc.displayAllSubject();
				showMenu();
				break;
			case "search":
				if(inputarr.length==2) {
					s = sc.getSubject(inputarr[1]);
					sc.showSubject(s);
				}
				showMenu();
				break;
			case "display":
				sc.displayAllSubject();
				showMenu();
				break;
			case "exit":
				mainMenu.showMenu();
				break;
			default:
				System.out.println("\nInvalid Input!");
				showMenu();
				break;
		}
	}

}
