package com.buksuIT.SIS;

import java.util.Scanner;

public class StudentMenu {
	Scanner scan = new Scanner(System.in).useDelimiter("\\n");
	MainMenu mainMenu;
	StudentController sc;
	
	
	public StudentMenu(MainMenu mainMenu,  StudentController studcon) {
		this.mainMenu = mainMenu;
		this.sc = studcon;
	}
	//To display Students Menu. The examples to follow so that the input is correct.
	public void showMenu()
	{
		System.out.println("\n==========================================STUDENT MENU==========================================");
		System.out.println("Add Student          --> add,Id,Name,Address,Age          (Ex: add,1001,Kenth,Jasaan,20)");
		System.out.println("Update Student       --> update,Id,Name,Address,Age       (Ex: update,1001,Kenth John,Jasaan,20)");
		System.out.println("Delete Student       --> delete,Id                        (Ex: delete,1001)");
		System.out.println("Search Student       --> search,Id                        (Ex: search,1001)");
		System.out.println("Display all Student  --> display                          (Ex: display)");
		System.out.println("Enroll Student       --> enroll,Id,Subject Code,          (Ex: enroll,1001,T232)");
		System.out.println("EXIT                 (Go to Main Menu)                    (Ex: exit)");
		System.out.println("==========================================STUDENT MENU==========================================");
		System.out.print("Please Input Command: ");
		
		String input = scan.nextLine();
	//Splitting the input in the String using comma
		String[] inputarr = input.split(",");
		
		Student s;
	//Expression of switch case.
		switch(inputarr[0].toLowerCase().trim())
		{
	//"add" is the value 1 and the command to add the student and the information to the students list.
			case "add":
				s = new Student(inputarr[1],inputarr[2],inputarr[3],Integer.parseInt(inputarr[4]));
				sc.add(s);
				sc.displayAllStudent();
				showMenu();
				break;
	//"update" is the value 2 and the command to update the students information in the students list.
			case "update": 
				s = new Student(inputarr[1],inputarr[2],inputarr[3],Integer.parseInt(inputarr[4]));
				sc.updateStudent(s);
				sc.displayAllStudent();
				showMenu();
				break;
	//"delete" is the value 3 and the command to delete a student and it's information in students list.
			case "delete": 
				sc.delete(inputarr[1]);
				sc.displayAllStudent();
				showMenu();
				break;
	//"search" is the value 4 and the command to search the student.
			case "search":
				s = sc.getStudent(inputarr[1]);
				sc.showStudent(s);
				showMenu();
				break;
	//"display" is the value 5 and the command to display all the student and the information.
			case "display":
				sc.displayAllStudent();
				showMenu();
				break;
   //"enroll" is the value 6 and the command to enroll the student in subjects and so that the student will have grades.
			case "enroll":
				sc.enroll(inputarr[1], inputarr[2]);
				showMenu();
				break;
	//"exit" is the value 7 and the command to go back in Main Menu.
			case "exit":				
					mainMenu.showMenu();
				break;
	//If the user don't follow the command.
			default:
				System.out.println("\nInvalid COMMAND!!");
				showMenu();
				break;

		}
	}
}
