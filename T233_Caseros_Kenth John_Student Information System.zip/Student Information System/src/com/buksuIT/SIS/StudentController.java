package com.buksuIT.SIS;

import java.util.LinkedList;


public class StudentController implements StudentMethods {
	LinkedList<Student> studentList = new LinkedList<Student>();
	SubjectController subjectController;

	StudentMenu studentMenu;
	
	
	public StudentController() {
	}
	public StudentController(SubjectController subjectController) {
		this.subjectController = subjectController;
	}
	public SubjectController getSubjectController() {
		return subjectController;
	}
	
	public void setSubjectController(SubjectController subjectController) {
		this.subjectController = subjectController;
	}
	//To add the a Students Information (ID, Name, Address, and Age) 
	@Override
	public Student add(Student s) {
		Student temp = getStudent(s.getId());
		if (temp != null) {
			System.out.println("\nFailed adding student! Student already exist.");
		} else if (idHasLetter(s.getId())) {
			System.out.println("\nInvalid ID! It should not have letter or special character");
		} else {
			studentList.add(s);
		}
		return s;
	}
    //To update the Students Information.
	@Override
	public Student updateStudent(Student s) {
		for (Student temp : studentList) {
			if (temp.getId().trim().equalsIgnoreCase(s.getId())) {
				temp.setName(s.getName());
				temp.setAddress(s.getAddress());
				temp.setId(s.getId());
				break;
			}
		}
		return s;
	}
	//To delete a Student in the Student List.
	@Override
	public Student delete(String id)
	{
		Student s=null;
		for(Student temp: studentList)
		{
			if(temp.id.equals(id))
			studentList.remove(temp);
			s=temp;
		}
	return s;
	}
	//To search Student using student's ID
	@Override
	public Student getStudent(String id) {
		Student s = null;
		for (Student temp : studentList) {
			if (temp.getId().trim().equalsIgnoreCase(id)) {
				s = temp;
				break;
			}
		}
		return s;
	}
	//To display Students List with Student ID, Name, Address, and Age.
	@Override
	public void displayAllStudent() {
		System.out.println("\n\t\t\t\tSTUDENT LIST\n");
		System.out.println("Student ID\t\tName\t\t\tAddress\t\t\tAge");
		System.out.println("==============================================================================");
		for (Student s : studentList) {
			System.out.printf("%s\t\t\t%s\t\t\t%s\t\t\t%d\n", s.getId(), s.getName(), s.getAddress(),s.getAge());
		}

	}
	//To display Students Information not just their ID, Name, Address, and Age but also their Subject List and their grades.
	@Override
	public void showStudent(Student s) {
		if (s != null) {
			System.out.println("\n\t\t\t\tSTUDENT INFORMATION\n");
			System.out.println("Student ID\t\tName\t\t\tAddress\t\t\tAge");
			System.out.println("==============================================================================");
			System.out.printf("%s\t\t\t%s\t\t\t%s\t\t\t%d\n", s.getId(), s.getName(), s.getAddress(),s.getAge());
			System.out.println("------------------------------------------------------------------------------");
			System.out.println("Subject List\t\t\t\t\tFinal Grades");
			System.out.println("==============================================================================");
			LinkedList<Subject> subjectList = s.getSubjectList();
			if(subjectList!=null) {
				for(Subject sub: subjectList)
				{
					String grade = " ";
					if(sub.getGradesList()!=null)
					{
						grade = sub.getStudentGrades(s.getId());
					}
					System.out.printf("%s\t\t\t\t\t\t%s\n",sub.getId(),grade);
				}
			}
		}

	}
	//To enroll student using Student's ID and the subject code they want to enroll.
	@Override
	public void enroll(String studentID, String subjectID) {
		Student s=getStudent(studentID);
	//If the student is not found, It can't enroll the subject.
		if(s==null)
		{
			System.out.println("Failed to add Subject! Student not found.");
			return;
		}
		Subject subject = subjectController.getSubject(subjectID);
	//If the student want to enroll but the subject is not found or It is not in the subject list.
		if(subject==null)
		{
			System.out.println("Failed to enroll Student! Subject not found.");
			return;
		}
		LinkedList<Subject> subjectList = s.getSubjectList();
		if(subjectList==null)
		{
			subjectList = new LinkedList<Subject>();
		}
		subjectList.add(subject);
		s.setSubjectList(subjectList);
		return;
	}
	//If the student list don't have any students.
	public void dropAllStudent() {
		studentList = null;
	}
	//Giving a student some grades using ID, Subject, and the grades.
	public void giveStudentGrades(String studID,String subject, String grades) {
		Student s = getStudent(studID);
	//If the Student ID not found, It can't give a grade to the student. 
		if(s==null)
		{
			System.out.println("Student not Found!");
			return;
		}
		
		LinkedList<Subject> subjectList = s.getSubjectList();
	//If the student is not yet enrolled to any subject.
		if(subjectList==null)
		{
			System.out.println("Student is not yet enrolled to any subject.");
			return;
		}
		boolean check=false;
		for(Subject sub: subjectList) {
			if(sub.getId().trim().equalsIgnoreCase(subject))
			{;
				Grades grade = new Grades(studID,subject,grades);
				LinkedList<Grades> gradesList = sub.getGradesList();
	//If the needed input was correct, the student will be given some grades.
				if(gradesList==null)
					{
						gradesList = new LinkedList<Grades>();
					}
					gradesList.add(grade);
					sub.setGradesList(gradesList);
					s.setSubjectList(subjectList);
					System.out.println("\n\nGiving Grades to the Student is Succesful!");
					check=true;
			}
		}
		if(!check)
		{
			System.out.println("Failed to give a Grade! Student is not yet enrolled in this subject.");
			return;
		}
	}
	//If the grades of the student need to update. 
	public void updateGrade(String studID,String subject, String grades)
	{
	//If the Students ID is not found.
		Student s = getStudent(studID);
		if(s==null)
		{
			System.out.println("Student not Found!");
			return;
		}
	//If the subject is found but the student is not yet enrolled.
		LinkedList<Subject> subjectList = s.getSubjectList();
		if(subjectList==null)
		{
			System.out.println("Student is not yet enrolled to any Subject.");
			return;
		}
		boolean check=false;
		for(Subject sub: subjectList) {
			if(sub.getId().trim().equalsIgnoreCase(subject))
			{
				for(Grades g: sub.getGradesList())
				{
					if(g.getId().trim().equalsIgnoreCase(studID))
					{
						g.setGrade(grades);
						check=true;
						break;
					}
				}
			}
		}
		if(!check)
		{
			System.out.println("Failed to give a Grade! Student is not yet enrolled in this subject.");
		}
	}

	public boolean idHasLetter(String id) {
		boolean check = false;
		for (int i = 0; i < id.length(); i++) {
			if (Character.isLetter(id.charAt(i))|| !Character.isLetter(id.charAt(i)) && !Character.isDigit(id.charAt(i))) {
				check = true;
				break;
			}			
		}
		return check;
	}
	

}
