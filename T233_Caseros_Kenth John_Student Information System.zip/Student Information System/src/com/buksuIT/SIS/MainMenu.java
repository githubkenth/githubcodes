package com.buksuIT.SIS;

import java.util.Scanner;

public class MainMenu {
	Scanner scan = new Scanner(System.in);
	SubjectController subcon;
	StudentController studcon;
	GradesController gradescon;
	StudentMenu studentMenu;
	SubjectMenu subjectMenu;
	GradesMenu gradesMenu;
	
	public MainMenu(SubjectController subcon, StudentController studcon,GradesController gradescon) {
		this.subcon = subcon;
		this.studcon = studcon;
		this.gradescon = gradescon;
		this.subjectMenu = new SubjectMenu(this,subcon);
		this.studentMenu = new StudentMenu(this,studcon);
		this.gradesMenu = new GradesMenu(this,subcon,studcon,gradescon);
	}
 //To display the Main Menu with the choices (Student Menu, Subject Menu, Grades Menu, and Exit)
	public void showMenu()
	{
		System.out.println("============================================MAIN MENU===========================================");
		System.out.println("1.Student Menu");
		System.out.println("2.Subject Menu");
		System.out.println("3.Grades Menu");
		System.out.println("4.Exit");
		System.out.println("============================================MAIN MENU===========================================");
		System.out.print("Please Select: ");
		
		String input = scan.nextLine();
		switch(input)
		{
		//For the Student Menu
			case "1": 
				studentMenu.showMenu();
				break;
		//For the Subject Menu
			case "2": 
				subjectMenu.showMenu();
				break;
		//For the Grades Menu
			case "3": 
				gradesMenu.showMenu();
				break;
		//For the Exit
			case "4": 
				System.out.println("Program Terminate!");
				break;
		//For the Invalid input (Letters, Numbers that are not available in the choices, etc. 
		   default: 
				System.out.println("\nInvalid Input!");
				showMenu();
				break;
		}
	}

}
