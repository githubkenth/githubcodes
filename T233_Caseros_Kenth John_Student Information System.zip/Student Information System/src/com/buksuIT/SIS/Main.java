package com.buksuIT.SIS;

public class Main {
	public static void main(String[]args)
	{
		//To access  Subject Menu in the Main Menu		
		SubjectController subcon = new SubjectController(); 
		//TO access Student Menu in the Main Menu
		StudentController studcon = new StudentController(subcon);
		//To access Grades Menu in the Main Menu
		GradesController gradecon = new GradesController(studcon);
		
		MainMenu mainMenu = new MainMenu(subcon,studcon,gradecon);
		
		mainMenu.showMenu();
	}

}
