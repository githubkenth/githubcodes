package com.buksuIT.SIS;

public interface GradesMethods {
	public Grades addGrades(Grades g);
	public Grades updateGrades(Grades g);
}