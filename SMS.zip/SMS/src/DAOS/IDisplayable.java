/**

* 
*IDisplayable is the interface created with the display() method.
*/
package DAOS;


public interface IDisplayable {

/**
*The method display() is implemented in the IDispayableImp.
*/
    public void display();
    

}
