package com.buksuIT.Queue;

import java.util.Scanner;

public class War {
    
    
    
    static Pile pile1;
    static Pile pile2;
    static int numTurns;
    
   
    
    public static void printPiles() {

      
       System.out.println("Turn: " + numTurns + System.lineSeparator());
       System.out.println("player1:");
       System.out.println(pile1 + System.lineSeparator());
       System.out.println("player2:");
       System.out.println(pile2);
       System.out.println("--------------------------------------");
    }
    
    public static void printWar() {

    
        System.out.println("                                        *** WAR! ***" + System.lineSeparator());
    }
    
  
    
    public static void main(String[] args) {
        
      Scanner scanner = new Scanner(System.in);
      System.out.println("Enter Player 1's cards (from top to bottom):");
      pile1 = new Pile(scanner.nextLine());
      System.out.println("Enter Player 2's cards (from top to bottom):");
      pile2 = new Pile(scanner.nextLine());

      numTurns = 1;
        
 
    }
}

