package com.buksuIT.SIS;

import java.util.LinkedList;

public class GradesController implements GradesMethods{
	LinkedList<Grades> gradesList = new LinkedList<Grades> ();
	StudentController studcon;
	public GradesController(StudentController studcon) {
		this.studcon = studcon;
	}

	@Override
	public Grades addGrades(Grades g) {
		Grades temp = getGrades(g.getGrade());
		if (temp != null) {
			System.out.println("\nFailed to Add Grade! This Student's subject is already Graded");
		}
		else {
			gradesList.add(g);
		}
		return g;
	}

	@Override
	public Grades updateGrades(Grades g) {
		for (Grades temp :gradesList) {
			if (temp.getGrade()==(g.getGrade())) {
				int index = gradesList.indexOf(temp);
				System.out.println(index);
				gradesList.set(index, g);
			}
		}
		return null;
	}
	public Grades getGrades(String grade)
	{
		Grades g = null;
		for(Grades temp: gradesList)
		{
			if (temp.getGrade()==grade) {
				g = temp;
				break;
			}
		}
		return g;
	}
}
