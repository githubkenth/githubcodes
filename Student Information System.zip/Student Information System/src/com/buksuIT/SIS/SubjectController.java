package com.buksuIT.SIS;

import java.util.LinkedList;

public class SubjectController  implements SubjectMethods{
	LinkedList<Subject> subjectList = new LinkedList<Subject> ();
	
	@Override
	//To add a subject in Subject list.
	public Subject add(Subject s) {
		Subject temp = getSubject(s.getId());
	// If the subject is already added, It can't be added again.
		if (temp != null) {
			System.out.println("\nFailed to add Subject! Subject already exist.");
		
		} else {
			subjectList.add(s);
		}
		return s;
	}
   //To update the subjects in subject list.
	@Override
	public Subject update(Subject s) {
		for (Subject temp : subjectList) {
			if (temp.getId().trim().equalsIgnoreCase(s.getId())) {
				int index = subjectList.indexOf(temp);
				System.out.println(index);
				subjectList.set(index, s);
				break;
			}
		}
		return null;
	}
   //To delete some subject in subject list.
	@Override
	public Subject delete(Subject s) {				
		subjectList.remove(s);		
		return s;
	}
  //To search subject using subject code.
	@Override
	public Subject getSubject(String id) {
		Subject s = null;
		for (Subject temp : subjectList) {
			if (temp.getId().trim().equalsIgnoreCase(id)) {
				s = temp;
				break;
			}
		}
		return s;
	}
  //To display all the subject added in subject list.
	@Override
	public void displayAllSubject() {
		System.out.println("\n\t\t\t\tSUBJECT LIST\n");
		System.out.println("Subject Code\t\t\t\t\t\tSubject Description");
		System.out.println("==============================================================================");
		for (Subject s : subjectList) {
			System.out.printf("%s\t\t\t\t\t\t\t%s\n", s.getId(), s.getName());
		}
		
	}
  //To display the subject information.
	@Override
	public void showSubject(Subject s) {
		if (s != null) {
			System.out.println("\n\t\t\t\tSUBJECT INFORMATION\n");
			System.out.println("Subject\t\t\t\t\t\t\tDescription");
			System.out.println("==============================================================================");
			System.out.printf("%s\t\t\t\t\t\t%s\n", s.getId(), s.getName());
		}
		
	}
	//If the subject is already added but the input are having a wrong subject code. 
	public void isExist(Subject s) {
		if (s == null) {
			System.out.println("\nSubject Code not found!");
		}			
		}	
	}
