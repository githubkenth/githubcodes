package com.buksuIT.MineSweeper;

class MainMinesweeper {
	public static void main(String[] args) {
		new WorldMinesweeper(WorldMinesweeper.DIFFICULTY[1]); // per default imposto la difficolta' a normal
	}
}