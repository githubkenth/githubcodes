package com.buksuIT.MineSweeper;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * @author Eric Beijer
 */
public class ControlPanel extends JPanel implements ActionListener
{
	private static final long serialVersionUID = 1L;
	private Minesweeper minesweeper;
	private Display mineDisplay, timeDisplay;
	private long begin;
	private Timer timer;
	
	public ControlPanel(Minesweeper minesweeper, Difficulty difficulty)
	{
		super(new BorderLayout());
		setBackground(Color.LIGHT_GRAY);
		this.minesweeper = minesweeper;
		
		mineDisplay = new Display(difficulty == Difficulty.BEGINNER ? 10 : difficulty == Difficulty.INTERMEDIATE ? 40 : 99);
		add(mineDisplay, BorderLayout.WEST);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		JButton btnNew = new JButton("New");
		btnNew.setBackground(Color.LIGHT_GRAY);
		btnNew.setFocusable(false);
		btnNew.addActionListener(this);
		panel.add(btnNew);
		add(panel, BorderLayout.CENTER);
		
		timeDisplay = new Display(0);
		add(timeDisplay, BorderLayout.EAST);
		
		begin = -1;
		timer = new Timer(100, this);
	}
	
	public void setMinesweeper(Difficulty difficulty)
	{
		timer.stop();
		mineDisplay.setValue(difficulty == Difficulty.BEGINNER ? 10 : difficulty == Difficulty.INTERMEDIATE ? 40 : 99);
		timeDisplay.setValue(0);
		begin = -1;
		repaint();
	}
	
	public void setMines(int value, boolean real)
	{
		if (real)
			mineDisplay.setValue(value);
		else
			mineDisplay.setValue(mineDisplay.getValue() + value);
		mineDisplay.repaint();
	}
	
	public void startTime()
	{
		if (begin != -1)
			return;
		begin = new Date().getTime();
		timer.start();
	}
	
	public int stopTime()
	{
		timer.stop();
		int retval = (int)((new Date().getTime() - begin) * 1000);
		return retval;
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getActionCommand() != null && e.getActionCommand().equals("New"))
			minesweeper.actionPerformed(e);
		else
		{
			timeDisplay.setValue((int)((new Date().getTime() - begin) / 1000));
			timeDisplay.repaint();
		}
	}
}