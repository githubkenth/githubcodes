package com.buksuIT.MineSweeper;

/**
 * @author Eric Beijer
 */
public enum Difficulty
{
	BEGINNER,
	INTERMEDIATE,
	EXPERT
}