package com.buksuIT.MineSweeper;

import java.awt.Color;
import java.awt.Graphics;

/**
 * @author Elridge
 */
public class Field
{
	private int x, y, neighbourMines;
	private boolean clicked, mine, flag, mineClicked;
	private Color color1, color2, color3, color4, color5, color6, color7, color8;
	
	public Field(int x, int y)
	{
		this.x = x;
		this.y = y;
		neighbourMines = 0;
		color1 = new Color(0, 0, 255);
		color2 = new Color(0, 128, 0);
		color3 = new Color(255, 0, 0);
		color4 = new Color(0, 0, 128);
		color5 = new Color(128, 0, 0);
		color6 = new Color(0, 128, 128);
		color7 = new Color(0, 0, 0);
		color8 = new Color(128, 128, 128);
		flag = mineClicked = false;
	}
	
	public boolean setClicked()
	{
		if (!flag)
		{
			clicked = true;
			mineClicked = mine;
			return !mine;
		}
		return true;
	}
	
	public boolean isClicked()
	{
		return clicked;
	}
	
	public void setMine(boolean mine)
	{
		this.mine = mine;
	}
	
	public void incrementNeighbourMines()
	{
		neighbourMines++;
	}
	
	public int getNeighbourMines()
	{
		return neighbourMines;
	}
	
	public int setFlag()
	{
		if (clicked)
			return 0;
		flag = !flag;
		return flag ? -1 : 1;
	}
	
	public boolean isFlag()
	{
		return flag;
	}
	
	public void setGameOver()
	{
		if (mine && !flag || !mine && flag)
			clicked = true;
	}
	
	public void setWon()
	{
		if (mine)
			flag = true;
	}
	
	public void paint(Graphics g)
	{
		Color back = mineClicked ? Color.RED : Color.LIGHT_GRAY;
		g.setColor(back);
		g.fillRect(x * 16, y * 16, 16, 16);
		
		if (clicked)
		{
			g.setColor(Color.GRAY);
			g.fillRect(x * 16, y * 16, 16, 1);
			g.fillRect(x * 16, y * 16 + 1, 1, 15);
			
			if (mine || !mine && flag)
			{
				g.setColor(Color.BLACK);
				g.fillRect(x * 16 + 4, y * 16 + 4, 9, 9);
				g.fillRect(x * 16 + 2, y * 16 + 8, 13, 1);
				g.fillRect(x * 16 + 8, y * 16 + 2, 1, 13);
				g.setColor(back);
				g.fillRect(x * 16 + 5, y * 16 + 4, 1, 1);
				g.fillRect(x * 16 + 11, y * 16 + 4, 1, 1);
				g.fillRect(x * 16 + 4, y * 16 + 5, 1, 1);
				g.fillRect(x * 16 + 12, y * 16 + 5, 1, 1);
				g.fillRect(x * 16 + 4, y * 16 + 11, 1, 1);
				g.fillRect(x * 16 + 12, y * 16 + 11, 1, 1);
				g.fillRect(x * 16 + 5, y * 16 + 12, 1, 1);
				g.fillRect(x * 16 + 11, y * 16 + 12, 1, 1);
				g.setColor(Color.WHITE);
				g.fillRect(x * 16 + 6, y * 16 + 6, 2, 2);
				
				if (!mine && flag)
				{
					g.setColor(Color.RED);
					g.drawLine(x * 16 + 2, y * 16 + 3, x * 16 + 13, y * 16 + 14);
					g.drawLine(x * 16 + 3, y * 16 + 3, x * 16 + 14, y * 16 + 14);
					g.drawLine(x * 16 + 2, y * 16 + 14, x * 16 + 13, y * 16 + 3);
					g.drawLine(x * 16 + 3, y * 16 + 14, x * 16 + 14, y * 16 + 3);
				}
				
				return;
			}
			
			switch (neighbourMines)
			{
				case 1:
					g.setColor(color1);
					g.fillRect(x * 16 + 5, y * 16 + 11, 7, 2);
					g.fillRect(x * 16 + 8, y * 16 + 3, 2, 8);
					g.fillRect(x * 16 + 7, y * 16 + 4, 1, 7);
					g.fillRect(x * 16 + 6, y * 16 + 5, 1, 2);
					g.fillRect(x * 16 + 5, y * 16 + 6, 1, 1);
					break;
				case 2:
					g.setColor(color2);
					g.fillRect(x * 16 + 3, y * 16 + 11, 10, 2);
					g.fillRect(x * 16 + 3, y * 16 + 10, 4, 1);
					g.fillRect(x * 16 + 4, y * 16 + 9, 5, 1);
					g.fillRect(x * 16 + 6, y * 16 + 8, 5, 1);
					g.fillRect(x * 16 + 8, y * 16 + 7, 4, 1);
					g.fillRect(x * 16 + 10, y * 16 + 5, 3, 2);
					g.fillRect(x * 16 + 3, y * 16 + 5, 3, 1);
					g.fillRect(x * 16 + 3, y * 16 + 4, 10, 1);
					g.fillRect(x * 16 + 4, y * 16 + 3, 8, 1);
					break;
				case 3:
					g.setColor(color3);
					g.fillRect(x * 16 + 3, y * 16 + 3, 7, 2);
					g.fillRect(x * 16 + 6, y * 16 + 7, 4, 2);
					g.fillRect(x * 16 + 3, y * 16 + 11, 7, 2);
					g.fillRect(x * 16 + 10, y * 16 + 3, 2, 10);
					g.fillRect(x * 16 + 12, y * 16 + 4, 1, 3);
					g.fillRect(x * 16 + 12, y * 16 + 9, 1, 3);
					break;
				case 4:
					g.setColor(color4);
					g.fillRect(x * 16 + 9, y * 16 + 3, 3, 10);
					g.fillRect(x * 16 + 3, y * 16 + 7, 10, 2);
					g.fillRect(x * 16 + 4, y * 16 + 5, 3, 2);
					g.fillRect(x * 16 + 5, y * 16 + 3, 3, 2);
					break;
				case 5:
					g.setColor(color5);
					g.fillRect(x * 16 + 3, y * 16 + 3, 10, 2);
					g.fillRect(x * 16 + 3, y * 16 + 5, 3, 2);
					g.fillRect(x * 16 + 3, y * 16 + 7, 9, 2);
					g.fillRect(x * 16 + 10, y * 16 + 8, 3, 4);
					g.fillRect(x * 16 + 3, y * 16 + 11, 9, 2);
					break;
				case 6:
					g.setColor(color6);
					g.fillRect(x * 16 + 4, y * 16 + 3, 8, 2);
					g.fillRect(x * 16 + 6, y * 16 + 7, 6, 2);
					g.fillRect(x * 16 + 4, y * 16 + 11, 8, 2);
					g.fillRect(x * 16 + 3, y * 16 + 4, 3, 8);
					g.fillRect(x * 16 + 10, y * 16 + 8, 3, 4);
					break;
				case 7:
					g.setColor(color7);
					g.fillRect(x * 16 + 3, y * 16 + 3, 10, 2);
					g.fillRect(x * 16 + 10, y * 16 + 5, 3, 2);
					g.fillRect(x * 16 + 9, y * 16 + 7, 3, 2);
					g.fillRect(x * 16 + 8, y * 16 + 9, 3, 2);
					g.fillRect(x * 16 + 7, y * 16 + 11, 3, 2);
					break;
				case 8:
					g.setColor(color8);
					g.fillRect(x * 16 + 4, y * 16 + 3, 8, 2);
					g.fillRect(x * 16 + 4, y * 16 + 7, 8, 2);
					g.fillRect(x * 16 + 4, y * 16 + 11, 8, 2);
					g.fillRect(x * 16 + 3, y * 16 + 4, 3, 3);
					g.fillRect(x * 16 + 10, y * 16 + 4, 3, 3);
					g.fillRect(x * 16 + 3, y * 16 + 9, 3, 3);
					g.fillRect(x * 16 + 10, y * 16 + 9, 3, 3);
					break;
			}
		}
		else
		{
			g.setColor(Color.WHITE);
			g.fillRect(x * 16, y * 16, 15, 1);
			g.fillRect(x * 16, y * 16 + 1, 14, 1);
			g.fillRect(x * 16, y * 16 + 2, 1, 13);
			g.fillRect(x * 16 + 1, y * 16 + 2, 1, 12);
			g.setColor(Color.GRAY);
			g.fillRect(x * 16 + 2, y * 16 + 14, 14, 1);
			g.fillRect(x * 16 + 1, y * 16 + 15, 15, 1);
			g.fillRect(x * 16 + 14, y * 16 + 2, 1, 12);
			g.fillRect(x * 16 + 15, y * 16 + 1, 1, 13);
			
			if (flag)
			{
				g.setColor(Color.BLACK);
				g.fillRect(x * 16 + 4, y * 16 + 11, 8, 2);
				g.fillRect(x * 16 + 6, y * 16 + 10, 4, 1);
				g.fillRect(x * 16 + 8, y * 16 + 8, 1, 2);
				g.setColor(Color.RED);
				g.fillRect(x * 16 + 7, y * 16 + 3, 2, 5);
				g.fillRect(x * 16 + 5, y * 16 + 4, 2, 3);
				g.fillRect(x * 16 + 4, y * 16 + 5, 1, 1);
			}
		}
		
		/*g.setColor(Color.LIGHT_GRAY);
		g.fillRect(x * width, y * width, width, width);
		g.setColor(clicked ? Color.GRAY : Color.WHITE);
		g.drawLine(x * width, y * width, x * width + width - 1, y * width);
		g.drawLine(x * width, y * width, x * width, y * width + width - 1);
		g.setColor(clicked ? Color.white : Color.GRAY);
		g.drawLine(x * width, y * width + width - 1, x * width + width, y * width + width - 1);
		g.drawLine(x * width + width - 1, y * width, x * width + width - 1, y * width + width - 1);
		
		if ((clicked || gameOver) && mine)
		{
			g.setColor(Color.BLACK);
			g.drawString("B", x * width + 5, y * width + 15);
		}
		else if (clicked && neighbourMines > 0)
		{
			g.setColor(neighbourMines == 1 ? color1 : neighbourMines == 2 ? color2 : neighbourMines == 3 ? color3 : neighbourMines == 4 ? color4 : neighbourMines == 5 ? color5 : neighbourMines == 6 ? color6 : neighbourMines == 7 ? color7 : color8);
			g.drawString(neighbourMines + "", x * width + 5, y * width + 15);
		}
		else if (flag)
		{
			g.setColor(Color.BLACK);
			g.fillRect(x * width + 3, y * width + 14, 13, 2);
			g.fillRect(x * width + 6, y * width + 13, 7, 1);
			g.fillRect(x * width + 10, y * width + 10, 1, 3);
			g.setColor(Color.RED);
			Polygon polygon = new Polygon();
			polygon.addPoint(x * width + 11, y * width + 3);
			polygon.addPoint(x * width + 11, y * width + 10);
			polygon.addPoint(x * width + 5, y * width + 7);
			g.fillPolygon(polygon);
			
			if (gameOver)
				;
			//g.setColor(gameOver ? Color.RED : Color.BLACK);
			//g.drawString("F", x * width + 5, y * width + 15);
		}*/
	}
}