package com.buksuIT.MineSweeper;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * @author Eric Beijer
 */
public class Minesweeper extends JFrame implements ActionListener
{
	private static final long serialVersionUID = 1L;
	private ControlPanel controlPanel;
	private MinesweeperPanel minesweeperPanel;
	private JCheckBoxMenuItem miBeginner, miIntermediate, miExpert;
	private Difficulty difficulty;
	
	public Minesweeper()
	{
		super("Minesweeper");
		setAlwaysOnTop(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
		difficulty = Difficulty.EXPERT;
		
		JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("File");
		JMenuItem menuItem = new JMenuItem("New");
		menuItem.addActionListener(this);
		menu.add(menuItem);
		menu.addSeparator();
		miBeginner = new JCheckBoxMenuItem("Beginner");
		miBeginner.addActionListener(this);
		menu.add(miBeginner);
		miIntermediate = new JCheckBoxMenuItem("Intermediate");
		miIntermediate.addActionListener(this);
		menu.add(miIntermediate);
		miExpert = new JCheckBoxMenuItem("Expert", true);
		miExpert.addActionListener(this);
		menu.add(miExpert);
		menu.addSeparator();
		menuItem = new JMenuItem("Exit");
		menuItem.addActionListener(this);
		menu.add(menuItem);
		menuBar.add(menu);
		setJMenuBar(menuBar);
		
		controlPanel = new ControlPanel(this, Difficulty.EXPERT);
		getContentPane().add(controlPanel, BorderLayout.NORTH);
		
		minesweeperPanel = new MinesweeperPanel(this, Difficulty.EXPERT);
		getContentPane().add(minesweeperPanel, BorderLayout.CENTER);
		
		pack();
		setLocationRelativeTo(null);
	}
	
	public void startTime()
	{
		controlPanel.startTime();
	}
	
	public void stopTime()
	{
		controlPanel.stopTime();
	}
	
	public void setMines(int value)
	{
		setMines(value, false);
	}
	
	public void setMines(int value, boolean real)
	{
		controlPanel.setMines(value, real);
	}
	
	public void setMainMenuDifficulty()
	{
		miBeginner.setSelected(difficulty == Difficulty.BEGINNER);
		miIntermediate.setSelected(difficulty == Difficulty.INTERMEDIATE);
		miExpert.setSelected(difficulty == Difficulty.EXPERT);
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if (e.getActionCommand().equals("New"))
		{
			controlPanel.setMinesweeper(difficulty);
			minesweeperPanel.setMinesweeper(difficulty);
		}
		else if (e.getActionCommand().equals("Beginner") || e.getActionCommand().equals("Intermediate") || e.getActionCommand().equals("Expert"))
		{
			difficulty = e.getActionCommand().equals("Beginner") ? Difficulty.BEGINNER : e.getActionCommand().equals("Intermediate") ? Difficulty.INTERMEDIATE : Difficulty.EXPERT;
			setMainMenuDifficulty();
			controlPanel.setMinesweeper(difficulty);
			minesweeperPanel.setMinesweeper(difficulty);
			pack();
		}
		else
			System.exit(0);
	}
	
	public static void main(String[] args)
	{
		try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
		catch (ClassNotFoundException e) { }
		catch (InstantiationException e) { }
		catch (IllegalAccessException e) { }
		catch (UnsupportedLookAndFeelException e) { }
		new Minesweeper();
	}
}