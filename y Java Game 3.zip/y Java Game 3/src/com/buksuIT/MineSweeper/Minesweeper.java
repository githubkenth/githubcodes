package com.buksuIT.MineSweeper;
public class Minesweeper{
    public static void main(String[] args) {
        new MineFrame(null);
    }
} 