package com.buksuIT.Tetris;

public class Main{

//To run the code
	
public static void main(String[] args) {
	Tetris tetris = new Tetris();
	tetris.startGame();
}
}

